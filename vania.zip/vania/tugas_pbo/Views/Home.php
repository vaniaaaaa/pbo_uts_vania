<body>

    <div class="card text-dark p-3 mb-2 bg-light text-dark">
  <div class="card-header">Project PTS PBO</div>
  <div class="card-body">
    <p class="card-text">
        Nama : Vania Agitha <br>
        Kelas: XII RPL-1 <br>
        Nomor Absen: 32
    </p>
  </div>
</div>

</body>