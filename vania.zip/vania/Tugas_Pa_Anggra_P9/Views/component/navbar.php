
<!doctype html>
<html lang="en" class="h-100">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Cover Template · Bootstrap v5.1</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/cover/">


    

    <!-- Bootstrap core CSS -->
<link href="/docs/5.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">


    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.1/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.1/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.1/assets/img/favicons/safari-pinned-tab.svg" color="#7952b3">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#7952b3">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
        nav {

          background-color: #000;
        }
        #nav-isi {

          position: relative;
          font-size: 15px;
          font-family: monospace;
          text-decoration: line;
          color: #A3A3A3;
          top: 10px;

        }

        #nav-isi:hover {
          
          color: white;
          text-shadow: 0px 0px 7px white;

        }
        nav h1 {

          margin-left: 1400px;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="cover.css" rel="stylesheet">
  </head>
  <body>
    
<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column" style="background-color: #000;">
  <header class="mb-auto">
   
    <div>
      
      <nav class="nav nav-masthead justify-content">
        
        <a id="nav-isi" class="nav-link active" aria-current="page" href="main.php?menu=<?php echo base64_encode(1) ?>">Kelas</a>
        <a id="nav-isi" class="nav-link" href="main.php?menu=<?php echo base64_encode(2) ?>">Pembayaran</a>
        <a id="nav-isi" class="nav-link" href="main.php?menu=<?php echo base64_encode(3) ?>">Petugas</a>
        <a id="nav-isi" class="nav-link active" aria-current="page" href="main.php?menu=<?php echo base64_encode(4) ?>">Siswa</a>
        <a id="nav-isi" class="nav-link" href="main.php?menu=<?php echo base64_encode(5) ?>">SPP</a>

        <h1>PBO</h1>
      </nav>
      
    </div>
   
  </header>

   <?php
                if(isset($_GET['menu']))
                {
                    $id = base64_decode($_GET['menu']);
                }
                else
                {
                    $id="";
                }
                    
                    if($id==1)
                    {
                        include('View_siswa.php');
                    }
                    elseif($id==2)
                    {
                        include('View_post_siswa.php');
                    }
                    elseif($id==3)
                    {
                        include('View_put_siswa.php');
                    }
                    elseif($id==4){
                        include('view_kelas.php');
                    }
                    elseif($id==5){
                        include('view_post_kelas.php');
                    }
                    elseif($id==6){
                        include('view_put_kelas.php');
                    }
                    else
                    {
                        echo "Selamat Datang";
                    }
                ?>

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    
  </body>
</html>
