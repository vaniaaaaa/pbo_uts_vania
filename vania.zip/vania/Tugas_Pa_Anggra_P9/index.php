<?php
  header('location:Views/main.php');
?>